class Tesla{ //inicio de la clase 
	Sbasico bas=new Sbasico();
	Slujo lujo=new Slujo();
	//Spremium prem=new Spremium();

	public static void main(String[] args){
		
		System.out.println("Serbicio basico ");
		//Sbasico bas=new Sbasico();
		Tesla tes=new Tesla();
		
		/*tes.bas.tempmotor();
		tes.bas.nivelaceite();
		tes.bas.nivelgasolina();
		//bas.apagarmotor();
		//bas.
		
		tes.lujo.estereo();
		tes.prem.serviciox();
		*/
		
	
	}




} //fin de la classe tesla 
